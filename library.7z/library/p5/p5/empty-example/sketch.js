function setup() {
  // put setup code here
}

function draw() {
  // put drawing code here
}